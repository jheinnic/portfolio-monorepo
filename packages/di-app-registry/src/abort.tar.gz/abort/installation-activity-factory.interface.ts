import {interfaces} from 'inversify';
import {ConcreteFactoryService} from '../interfaces/concrete-factory-service.interface';
import {InstallationActivity} from './installation-activity.interface';

export type InstallationActivityFactory<In, Out> =
   ConcreteFactoryService<'begin', InstallationActivity<Out>, [In]>;

