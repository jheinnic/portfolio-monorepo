import {ConcreteFactoryService} from '../interfaces/concrete-factory-service.interface';

// type InstallerFunction<Args extends any[] = []> =
//    (moduleCallback: interfaces.ContainerModuleCallBack) =>
//       (...args: Args) => interfaces.ContainerModuleCallBack;

// export type InstallerFunction<F extends InstallerFactory<any[]>> =
//    F extends ((moduleCallback: interfaces.ContainerModuleCallBack) =>
//       (...args: infer Args) => interfaces.ContainerModuleCallBack)
//       ? InstallerFactory<Args> : never;

// export interface InstallerFactory<Args extends any[] = any[]> {
//    (...args: Args): ContainerModuleCallBack;
// }

export type DeployedInstallerService<Imports, Exports> =
   ConcreteFactoryService<'install', Exports, [Imports]>;

