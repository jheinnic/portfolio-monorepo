import {interfaces} from 'inversify';
import {InstallationActivityFactory} from './installation-activity-factory.interface';
import ServiceIdentifier = interfaces.ServiceIdentifier;

export type InstallModuleIdentifier<I, O> =
   ServiceIdentifier<InstallationActivityFactory<I, O>>;

// I extends InstallerFactory ? ServiceIdentifier<Parameters<ReturnType<I>>> :
//    ServiceIdentifier<Parameters<ReturnType<(I&InstallerService)['install']>>>

