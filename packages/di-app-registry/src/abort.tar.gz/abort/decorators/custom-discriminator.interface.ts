import {IContainerAccessStrategy} from '../../interfaces/installer/container-access-strategy.interface';

export interface CustomDiscriminator<T = any> {
   type: 'custom';
   accessStrategy: IContainerAccessStrategy<T>
}