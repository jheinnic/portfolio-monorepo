import {ApplicationInstaller} from '../interfaces/index';

export interface IApplicationBindingSyntax<A extends ApplicationInstaller>
{
   to(constructor: {new(...args: any[]): A}): void;
}
