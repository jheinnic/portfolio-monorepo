import {interfaces} from 'inversify';
import ContainerModuleCallBack = interfaces.ContainerModuleCallBack;
import {AnyFunc} from 'simplytyped';

import {INestedContainerBindingSyntax, INestedContainerAgent} from '../interfaces/index';
import {ContainerRegistryInternal} from '../container-registry-internal.interface';
import {DI_TYPES} from '../types/index';

export class NestedContainerBindingSyntax<C extends INestedContainerAgent>
   implements INestedContainerBindingSyntax<C>
{
   constructor(
      private readonly internalCb: ContainerRegistryInternal,
      private readonly bindTo: interfaces.BindingToSyntax<any>) { }

   public to(installer: { new(...args: any[]): C }): void
   {
      this.bindTo.to(installer)
         .onActivation(
            (context: interfaces.Context, value: (C)): C => {
               let handler = {
                  apply: (
                     target: AnyFunc, thisArgument: C,
                     argumentsList: Parameters<C['install']>) =>
                  {
                     this.internalCb.scanForRegistryDecorators(argumentsList);
                     this.internalCb.beginNestedContainer(argumentsList[0]);
                     // console.log(`Starting: ${new Date().getTime()}`);
                     let result: ContainerModuleCallBack =
                        target.apply(thisArgument, argumentsList);
                     // console.log(`Finished: ${new Date().getTime()}`);
                     // context.container.load(
                     //    new ContainerModule(result));
                     this.internalCb.completeNestedContainer(argumentsList[0], result);

                     context.container.bind(DI_TYPES.NestedContainer)
                        .toConstantValue(result);

                     return result;
                  }
               };
               value.install = new Proxy(value.install, handler);

               return value;
            }
         );
   }
}